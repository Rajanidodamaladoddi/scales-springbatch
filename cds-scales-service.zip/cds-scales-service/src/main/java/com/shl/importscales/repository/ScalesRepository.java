package com.shl.importscales.repository;

import com.shl.importscales.model.Scales;
import org.springframework.data.jpa.repository.JpaRepository;

public interface ScalesRepository extends JpaRepository<Scales, Long> {
}
