package com.shl.importscales.batch;

import com.shl.importscales.model.Scales;
import org.springframework.batch.item.ItemProcessor;
import org.springframework.stereotype.Component;

@Component
public class Processor implements ItemProcessor<Scales, Scales> {

	public Processor() {
	}

	@Override
	public Scales process(Scales scales) throws Exception {
		System.out.println("Processor is being called");
		if(!isValid(scales)){
			return null;
		}
		
		/*Scales scale = new Scales();
		scale.setTag(scales.getTag());
		//scale.setName(scales.getName());
		scale.setDescription(scales.getDescription());
		scale.setActive(scales.isActive());
		scale.setEquation(scales.getEquation());
		scale.setFrameworkName(scales.getFrameworkName());
		scale.setStartingTheta(scales.getStartingTheta());
		return scale;*/
		return scales;
	}
	
	boolean isValid(Scales scales){
		System.out.println("isValid is being called");
		return (scales.getTag().isEmpty())?false:true;
	}
}
