package com.shl.importscales.config;

import com.shl.importscales.model.Scales;
import com.shl.importscales.repository.ScalesRepository;

import org.springframework.batch.core.ItemProcessListener;
import org.springframework.batch.core.Job;
import org.springframework.batch.core.Step;
import org.springframework.batch.core.configuration.annotation.EnableBatchProcessing;
import org.springframework.batch.core.configuration.annotation.JobBuilderFactory;
import org.springframework.batch.core.configuration.annotation.StepBuilderFactory;
import org.springframework.batch.core.launch.support.RunIdIncrementer;
import org.springframework.batch.extensions.excel.RowMapper;
import org.springframework.batch.extensions.excel.mapping.BeanWrapperRowMapper;
import org.springframework.batch.extensions.excel.poi.PoiItemReader;
import org.springframework.batch.item.ItemProcessor;
import org.springframework.batch.item.ItemReader;
import org.springframework.batch.item.ItemWriter;
import org.springframework.batch.item.validator.SpringValidator;
import org.springframework.batch.item.validator.ValidatingItemProcessor;
import org.springframework.batch.item.validator.Validator;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.core.io.FileSystemResource;

@Configuration
@EnableBatchProcessing
public class SpringBatchConfig {

	@Autowired
	private ScalesRepository scalesRepository;

	@Bean
    public Job job(JobBuilderFactory jobBuilderFactory,
                   StepBuilderFactory stepBuilderFactory,
                   ItemReader<Scales> itemReader,
                   ItemProcessor<Scales, Scales> itemProcessor,
                   ItemWriter<Scales> itemWriter
    )throws Exception {

        Step step = stepBuilderFactory.get("ETL-file-load")
                .<Scales, Scales>chunk(100)
                .reader(itemReader)
                .listener(new InvalidItemsListener())
                .processor(itemProcessor)
                .writer(itemWriter)
                .faultTolerant().skipPolicy(skipPolicy())
                .build();


        return jobBuilderFactory.get("ETL-Load")
                .incrementer(new RunIdIncrementer())
                .start(step)
                .build();
    }

	@Bean
	public org.springframework.validation.Validator validator() {
    // see https://docs.spring.io/spring/docs/current/spring-framework-reference/core.html#validation-beanvalidation-spring
    return new org.springframework.validation.beanvalidation.LocalValidatorFactoryBean();
    }

	@Bean
	public Validator<Scales> springValidator() {
		SpringValidator<Scales> springValidator = new SpringValidator<>();
		springValidator.setValidator(validator());
		return springValidator;
	}

	@Bean
	public ItemProcessor<Scales, Scales> itemProcessor() {
		ValidatingItemProcessor<Scales> validatingItemProcessor = new ValidatingItemProcessor<>(springValidator());
		validatingItemProcessor.setFilter(true);
		return validatingItemProcessor;
	}


	@Bean
	public ItemReader<Scales> itemReader() {

		PoiItemReader<Scales> scales = new PoiItemReader<Scales>();
		scales.setLinesToSkip(1);
		scales.setStrict(false);
		scales.setResource(new FileSystemResource("src/main/resources/Scales_Import_Invalid_data.xlsx"));
		scales.setRowMapper(excelRowMapper());
		return scales;
	}

	private RowMapper<Scales> excelRowMapper() {
		BeanWrapperRowMapper<Scales> rowMapper = new BeanWrapperRowMapper<>();
		rowMapper.setTargetType(Scales.class);
		return rowMapper;
	}

	static class InvalidItemsListener implements ItemProcessListener<Scales, Scales> {

		@Override
		public void beforeProcess(Scales item) {
			// TODO Auto-generated method stub

		}

		@Override
		public void afterProcess(Scales item, Scales result) {
			// TODO Auto-generated method stub
			if (result.getTag() == null) {
				System.out.println("Tag has been filtered because it is invalid");
			}
		}

		@Override
		public void onProcessError(Scales item, Exception e) {
			// TODO Auto-generated method stub

		}

	}
	
	public JobSkipPolicy skipPolicy(){
		return new JobSkipPolicy();		
	} 
}
