package com.shl.importscales.batch;

import com.shl.importscales.model.Scales;
import com.shl.importscales.repository.ScalesRepository;
import org.springframework.batch.item.ItemWriter;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.util.List;

@Component
public class DBWriter implements ItemWriter<Scales> {

    private ScalesRepository scalesRepository;

    @Autowired
    public DBWriter (ScalesRepository scalesRepository) {
        this.scalesRepository = scalesRepository;
    }

    @Override
    public void write(List<? extends Scales> scales) throws Exception{
        System.out.println("Data Saved for Scales: " + scales);
        scalesRepository.saveAll(scales);
    }
}
