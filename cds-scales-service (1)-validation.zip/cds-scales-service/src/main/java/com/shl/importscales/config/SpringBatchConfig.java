package com.shl.importscales.config;

import com.shl.importscales.model.Scales;
import com.shl.importscales.repository.ScalesRepository;

import org.springframework.batch.core.ItemProcessListener;
import org.springframework.batch.core.Job;
import org.springframework.batch.core.Step;
import org.springframework.batch.core.configuration.annotation.EnableBatchProcessing;
import org.springframework.batch.core.configuration.annotation.JobBuilderFactory;
import org.springframework.batch.core.configuration.annotation.StepBuilderFactory;
import org.springframework.batch.core.launch.support.RunIdIncrementer;
import org.springframework.batch.extensions.excel.RowMapper;
import org.springframework.batch.extensions.excel.mapping.BeanWrapperRowMapper;
import org.springframework.batch.extensions.excel.poi.PoiItemReader;
import org.springframework.batch.item.ItemProcessor;
import org.springframework.batch.item.ItemReader;
import org.springframework.batch.item.ItemWriter;
import org.springframework.batch.item.validator.SpringValidator;
import org.springframework.batch.item.validator.ValidatingItemProcessor;
import org.springframework.batch.item.validator.Validator;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.core.io.FileSystemResource;

@Configuration
@EnableBatchProcessing
public class SpringBatchConfig {

	
	@Bean
	public Job job(JobBuilderFactory jobBuilderFactory, StepBuilderFactory stepBuilderFactory,
			ItemReader<Scales> itemReader, ItemProcessor<Scales, Scales> itemProcessor, ItemWriter<Scales> itemWriter)
			throws Exception {

		Step step = stepBuilderFactory.get("ETL-file-load")
				.<Scales, Scales>chunk(1)
				.reader(itemReader)
				.processor(itemProcessor)
				.writer(itemWriter)
				// .faultTolerant().skipPolicy(skipPolicy())
				.build();

		return jobBuilderFactory.get("ETL-Load")
				.incrementer(new RunIdIncrementer())
				.start(step)
				.build();
	}

	@Bean
	public ItemReader<Scales> itemReader() {

		PoiItemReader<Scales> scales = new PoiItemReader<Scales>();
		scales.setLinesToSkip(1);
		scales.setStrict(false);
		scales.setResource(new FileSystemResource("src/main/resources/Scales_Import_Invalid_data.xlsx"));
		scales.setRowMapper(excelRowMapper());
		return scales;
	}

	private RowMapper<Scales> excelRowMapper() {
		BeanWrapperRowMapper<Scales> rowMapper = new BeanWrapperRowMapper<>();
		rowMapper.setTargetType(Scales.class);
		return rowMapper;
	}

}
