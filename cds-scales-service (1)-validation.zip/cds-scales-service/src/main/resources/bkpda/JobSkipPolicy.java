package com.shl.importscales.config;

import org.springframework.batch.core.step.skip.SkipLimitExceededException;
import org.springframework.batch.core.step.skip.SkipPolicy;

/*public class JobSkipPolicy implements SkipPolicy{

	@Override
	public boolean shouldSkip(Throwable t, int failedCount) throws SkipLimitExceededException {
		// TODO Auto-generated method stub
		//return (failedCount>=1)?true:false;
		System.out.println("I am from JobSkipPolicy..." +failedCount);
		return true;
	}

}*/
